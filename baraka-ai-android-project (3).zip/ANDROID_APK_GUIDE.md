# Mwongozo Rasmi wa Kujenga na Kupakua Android APK ya Baraka AI Tanzania 🇹🇿
*(Official Guide to Build and Download Baraka AI Tanzania Android APK via GitHub Actions)*

---

### Hali ya Sasa (Current Status)
* **Mradi wa Ndani wa Android (Capacitor Android Native Project)**: ✅ Upo tayari kwenye folda ya `android/`
* **Vipengee vya Wavuti (Web Assets)**: ✅ Vimesawazishwa kikamilifu kwenye `android/app/src/main/assets/public/`
* **Workflow ya GitHub Actions**: ✅ Imesanidiwa kikamilifu kwenye `.github/workflows/build-apk.yml`
* **Utegemezi wa Maktaba (Lockfile & Dependencies)**: ✅ `package-lock.json` imetengenezwa bila hitilafu zozote za `peerDependencies`
* **Faili la APK ya Sasa (`.apk`)**: ⚠️ **Bado halijajengwa (NOT yet built)** kwa sababu mazingira ya seva ya Google AI Studio hayana Java JDK wala Android SDK Compiler. Ujenzi halisi wa binary ya APK unaendeshwa kiotomatiki na **GitHub Actions** (ambao wana Android SDK na JDK 17).

---

## 🚀 Hatua 4 Rahisi za Kujenga na Kupakua APK Kupitia GitHub Actions

### Hatua ya 1: Fungua Repository Mpya kwenye GitHub (Create GitHub Repo)
1. Ingia kwenye akaunti yako ya [GitHub](https://github.com) kupitia simu au kompyuta yako.
2. Bonyeza kitufe cha **+** (New Repository) juu kulia:
   * **Repository name**: `baraka-ai-tanzania`
   * Chagua **Public** au **Private** (zote zinakubaliwa).
   * **Usiweke tiki** kwenye "Add a README file" au ".gitignore" (kwa sababu mradi tayari una faili hizi).
3. Bonyeza **Create repository**.

---

### Hatua ya 2: Pakia Mradi Kwenye GitHub (Push Code to GitHub)

#### Chaguo A (Kupitia Kompyuta au Terminal - Njia ya Haraka Zaidi):
Mradi huu tayari umewekwa `git init` na commit ya kwanza imekamilika (`main` branch).
Endesha amri hizi mbili tu:
```bash
git remote add origin https://github.com/<JINA_LAKO_LA_GITHUB>/baraka-ai-tanzania.git
git branch -M main
git push -u origin main
```

#### Chaguo B (Bila Terminal - Kutumia faili la ZIP):
1. Pakua faili la mradi kupitia kiungo hiki cha programu:
   * **Folda Yote ya Mradi**: `https://ais-dev-v2r64rb3f7qtldrmrbn6y7-770206708085.europe-west2.run.app/api/backup.zip`
   * **Mradi wa Android Pekee**: `https://ais-dev-v2r64rb3f7qtldrmrbn6y7-770206708085.europe-west2.run.app/api/android-package.zip`
2. Fungua (extract) faili la ZIP.
3. Kwenye ukurasa wako wa GitHub repo uliyoifungua, bonyeza **"uploading an existing file"** na buruta/pakia mafolda na faili ikiwemo `.github/` na `android/`.
4. Bonyeza **Commit changes**.

---

### Hatua ya 3: Ujenzi wa APK Kwenye GitHub Actions (Trigger the Build)
1. Mara baada ya kupakia msimbo, nenda kwenye kichupo cha **"Actions"** kwenye GitHub repo yako:
   `https://github.com/<JINA_LAKO_LA_GITHUB>/baraka-ai-tanzania/actions`
2. Utaona mtiririko uitwao:
   **"Jenga Android APK (Build Baraka AI APK)"**
3. Ikiwa haikuanza kiotomatiki, bofya jina hilo upande wa kushoto, kisha bonyeza kitufe cha kulia:
   👉 **Run workflow** > chagua tawi la `main` > bonyeza **Run workflow**.
4. GitHub itaanza kujenga papo hapo:
   * Hatua ya 1: `Setup Node.js & JDK 17`
   * Hatua ya 2: `npm ci && npm run build`
   * Hatua ya 3: `npx cap sync android`
   * Hatua ya 4: `./gradlew assembleDebug`
   * Hatua ya 5: `Upload APK Artifact`
5. Ujenzi unachukua takriban **dakika 2 hadi 3 tu**.

---

### Hatua ya 4: Pakua Faili la APK Moja kwa Moja kwenye Simu Yako (Download the APK)
1. Mara baada ya ujenzi kukamilika (utaona alama ya tiki ya kijani ✅ **Success**):
2. Bofya jina la ujenzi huo (k.m. *"Kujenga APK ya Baraka AI"* au nambari ya run).
3. Shuka chini kabisa hadi sehemu iliyoandikwa **Artifacts**.
4. Utaona faili lililoandikwa:
   📦 **`BarakaAI-Tanzania-debug-apk`**
5. Bonyeza kiungo hicho — kivinjari chako cha simu (Chrome au nyingine) kitapakua faili la ZIP lenye **`app-debug.apk`**.
6. Fungua faili hilo kwenye simu yako na ubofye **Install / Sakinisha**. Programu yako ya **Baraka AI Tanzania** itasakinishwa na kufunguka mara moja kama app asilia ya Android!

---

## 🛠️ Muhtasari wa Faili Zilizosanidiwa

| Faili | Jukumu Lake |
|---|---|
| `.github/workflows/build-apk.yml` | Mtiririko wa kiotomatiki wa GitHub Actions unaojenga APK na kuipakia kama Artifact |
| `capacitor.config.ts` | Usanidi wa Capacitor (ID: `com.barakaai.tanzania`, Jina: `Baraka AI Tanzania`) |
| `android/app/build.gradle` | Mipangilio ya moduli ya Android (SDK 24-36, Proguard, AndroidX) |
| `android/app/src/main/AndroidManifest.xml` | Ruhusa za Android (`INTERNET`, `RECORD_AUDIO`, `MODIFY_AUDIO_SETTINGS`) |
| `package-lock.json` | Orodha kamili ya utegemezi wa npm ili `npm ci` isikwame kwenye GitHub Actions |
